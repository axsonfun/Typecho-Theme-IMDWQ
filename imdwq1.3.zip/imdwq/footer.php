</main><action><button class="top"><i class="fa fa-arrow-up"></i></button></action><footer><p id="dibu"><?php $this->options->footer(); ?></p></footer><script src="https://cdn.jsdelivr.net/npm/pjax/pjax.js"></script><script src="<?php $this->options->themeUrl('js.js'); ?>"></script></script>    <script src="//cdn1.lncld.net/static/js/3.0.4/av-min.js"></script>
    <script src='//unpkg.com/valine/dist/Valine.min.js'></script>
<style>
.info {display: none;}.v .vwrap {border: 2px solid #f6a900;border-radius: 12px;}.markdown{display: none;}button.vsubmit.vbtn{color: #fff;background: #f6a900;border: 1px solid #f6a900;border-radius: 12px;}button.vsubmit.vbtn:hover{color: #fff;background: rgb(221, 152, 0);border: 1px solid rgb(221, 152, 0);}
input::-webkit-input-placeholder{color:#f6a900;}input::-moz-placeholder{color:#f6a900;}input:-moz-placeholder{color:#f6a900;}input:-ms-input-placeholder{color:#f6a900;}textarea::-webkit-input-placeholder{color:#f6a900;}textarea::-moz-placeholder{color:#f6a900;}textarea:-moz-placeholder{color:#f6a900;}textarea:-ms-input-placeholder{color:#f6a900;}.vheader item3{color:#f6a900;}.vedit{color:#f6a900;}.vpreview-btn{color:#f6a900;}.vemoji-btn{color:#f6a900;}.vctrl{color:#f6a900;}
</style><script>
new Valine({
    el: '#vcomments' ,
    appId: 'gFLiluUuu7j36IYryGlOzTrV-gzGzoHsz',
    appKey: 'ou1WI3H44yUvfBoNMQJY2V3D',
    notify:false, 
    verify:false, 
    avatar:'mp', 
    placeholder: '您的留言可以一阵见血！' 
});
    </script></body></html>