<?php
/**
 * 搜索模板
 *
 * @package custom
 */
 ?>
<?php $this->need('head.php'); ?>
<?php $this->need('sidebar.php'); ?>
<main class="is-article">
<br>
<section class="page">
<section class="me" style="text-align: center;">
        <div class="my-avatar" style="display: contents;margin: 0 auto;">
            <img style="max-height: 144px;border-radius: 0;" src="https://ae01.alicdn.com/kf/HTB1v4ldbYus3KVjSZKb760qkFXaT.png">
        </div>
        <div class="my-info">
            <h1 style="margin-bottom: 0;"><?php $this->title() ?></h1>
        </div>
    </section>
<div class="news-head" style="text-align: center;">
<h3 class="title" style="display: block;"><a onclick ="so()"><i class="fa fa-search"></i></a><form id="dakuang" method="post" name="myform" onkeydown="if(event.keyCode==13){return false;}">
    <div><input id="xiaokuang" type="text" name="name" class="text" size="32" style="width: 100%;border: 0;margin-top: -20px;margin-bottom: -16px;" autofocus="autofocus" placeholder="输入关键词搜索"/></div>
</form></h3>
</div>
<a href="search" id="overso" style="display:none"></a>
</section>
<script type="text/javascript">
function so(){
var name=document.myform.name.value;
var overhref = "search/"+name;
document.getElementById("overso").setAttribute("href",overhref); 
document.getElementById("overso").click();
};
</script>
<?php $this->need('footer.php'); ?>