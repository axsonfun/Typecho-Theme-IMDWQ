<?php $this->need('head.php'); ?>
<?php $this->need('sidebar.php'); ?>
<main class="is-article"><br><section class="page"><section class="project-head project-list"><a><img src="<?php $this->fields->toutu(); ?>"/></a></section><article class="paul-post"><?php $this->content(); ?></article></section>
<?php $this->need('footer.php'); ?>