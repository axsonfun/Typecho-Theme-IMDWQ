<?php
function theNext($widget, $default = NULL) {
  $db = Typecho_Db::get();
  $sql = $db->select()->from('table.contents')
   ->where('table.contents.created > ?', $widget->created)
   ->where('table.contents.status = ?', 'publish')
   ->where('table.contents.type = ?', $widget->type)
   ->where('table.contents.password IS NULL')
   ->order('table.contents.created', Typecho_Db::SORT_ASC)
   ->limit(1);
  $content = $db->fetchRow($sql);
  if ($content) {
    $content = $widget->filter($content);
    $link = '<a href="'.$content['permalink'].'" class="mdui-btn cui-shadow-light-blue mdui-ripple" style="border-radius:0 1000px 1000px 0 ;margin-top: 6px;color: #5493FF;background: #e8f0fe;float: right;margin-right: 48px;" >下一篇:'.$content['title'].'<i class="mdui-icon material-icons" style="margin-bottom: 2px;">&#xe5cc;</i></a>';
    echo $link;
  } else {
    echo $default;
  }
}
function thePrev($widget, $default = NULL) {
  $db = Typecho_Db::get();
  $sql = $db->select()->from('table.contents')
   ->where('table.contents.created < ?', $widget->created)
   ->where('table.contents.status = ?', 'publish')
   ->where('table.contents.type = ?', $widget->type)
   ->where('table.contents.password IS NULL')
   ->order('table.contents.created', Typecho_Db::SORT_DESC)
   ->limit(1);
  $content = $db->fetchRow($sql);
  if ($content) {
    $content = $widget->filter($content);
    $link = '<a href="'.$content['permalink'].'" class="mdui-btn cui-shadow-light-blue mdui-ripple" style="border-radius: 1000px 0 0 1000px;margin-top: 6px;color: #5493FF;background: #e8f0fe;float: left;margin-left: 48px;" ><i class="mdui-icon material-icons" style="margin-bottom: 2px;">&#xe5cb;</i>上一篇:'.$content['title'].'</a>';
    echo $link;
  } else {
    echo $default;
  }
}
function themeConfig($form) {
	$touxiang = new Typecho_Widget_Helper_Form_Element_Text('touxiang', NULL, NULL, _t('头像'), _t(''));
    $form->addInput($touxiang);
	$name = new Typecho_Widget_Helper_Form_Element_Text('name', NULL, NULL, _t('昵称'), _t(''));
    $form->addInput($name);
    $jieshao = new Typecho_Widget_Helper_Form_Element_Text('jieshao', NULL, NULL, _t('介绍'), _t(''));
    $form->addInput($jieshao);
	$footer = new Typecho_Widget_Helper_Form_Element_Text('footer', NULL, NULL, _t('底部'), _t(''));
    $form->addInput($footer);
    $biaoti = new Typecho_Widget_Helper_Form_Element_Text('biaoti', NULL, NULL, _t('标题'), _t(''));
    $form->addInput($biaoti);
	$guanjianci = new Typecho_Widget_Helper_Form_Element_Text('guanjianci', NULL, NULL, _t('关键词'), _t(''));
    $form->addInput($guanjianci);
	$miaoshu = new Typecho_Widget_Helper_Form_Element_Text('miaoshu', NULL, NULL, _t('描述'), _t(''));
    $form->addInput($miaoshu);
	$icon = new Typecho_Widget_Helper_Form_Element_Text('icon', NULL, NULL, _t('图标'), _t(''));
    $form->addInput($icon);
	$lianxi = new Typecho_Widget_Helper_Form_Element_Text('lianxi', NULL, NULL, _t('联系'), _t('<a href="链接" target="_blank" ks-tag="bottom" ks-text="名字"><i class="fa 图标" style="color: 颜色"></i></a>例子F12看这里'));
    $form->addInput($lianxi);
	$celan = new Typecho_Widget_Helper_Form_Element_Text('celan', NULL, NULL, _t('侧栏'), _t('<a href="链接"><i class="fa 图标"></i><span>名称</span></a>例子F12看这里'));
    $form->addInput($celan);
}
function themeFields($layout) {
    $toutu = new Typecho_Widget_Helper_Form_Element_Text('toutu', NULL, NULL, _t('文章头图'), _t(''));
    $layout->addItem($toutu);
	$biaoti = new Typecho_Widget_Helper_Form_Element_Text('biaoti', NULL, NULL, _t('标题'), _t(''));
    $layout->addItem($biaoti);
	$guanjianci = new Typecho_Widget_Helper_Form_Element_Text('guanjianci', NULL, NULL, _t('关键词'), _t(''));
    $layout->addItem($guanjianci);
	$miaoshu = new Typecho_Widget_Helper_Form_Element_Text('miaoshu', NULL, NULL, _t('描述'), _t(''));
    $layout->addItem($miaoshu);
}
?>