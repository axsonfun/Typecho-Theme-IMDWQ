/* ----
Paul Integration
By: Dreamer-Paul
Integration: DengWeiQiang
Last Update: 2019.6.6
保罗的个人首页，自创的内容管理系统。本代码为奇趣保罗原创，并遵守 MIT 开源协议。欢迎访问我的博客：https://paugram.com
---- */
var paul = new function () {
    var that = this;
    var ajax = {
        note: {},
        gallery: {}
    };
    this.getByName = function (name) {
        return document.getElementsByName(name)[0];
    };
    this.add_zero = function (num) {
        return num < 10 ? "0" + num : num;
    };
    var head = {
        wrap: ks.select("header")
    }
    ks.select("toggle").onclick = function (){
        head.wrap.classList.toggle("active");
    }
    ks("header nav a").each(function(t){
        t.onclick = head.wrap.classList.remove("active");
    });
    this.side = function () {
        var el = {
            top: ks.select("action .top"),
            player: ks.select("action .player")
        };
        el.top.onclick = function () {
            if('scrollBehavior' in document.documentElement.style){
                window.scrollTo({top: 0, behavior: "smooth"})
            }
            else{
                window.scrollTo(0, 0);
            }
        };
        window.onscroll = function () {
            var scroll = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
            scroll >= window.innerHeight / 1.5 ? el.top.classList.add("active") : el.top.classList.remove("active");
        };
    };   
    this.init = function () {
        if(ks.select(".paul-news")) this.indexPage();
        if(ks.select(".paul-note")) this.notePage();
        if(ks.select(".paul-gallery")) this.galleryPage();
        if(ks.select(".paul-music")) this.musicPage();
        this.side();
        if(typeof _hmt !== 'undefined') _hmt.push(['_trackPageview', location.pathname + location.search]);

        ks.image("article img, .paul-say img, .project-screenshot img, .gallery-item");
    };
    var pjax = new Pjax({
        elements: "a[href]:not([target=_blank])",
        selectors: [
            "title", "meta[name=description]", "meta[property]", "main", "action"
        ],
        timeout: 10000,
        cacheBust: false
    });  
    document.addEventListener('pjax:send', function (){
        document.body.classList.add("loading");
        head.wrap.classList.remove("active");
    });
    document.addEventListener('pjax:complete', function (){
        document.body.classList.remove("loading");
        paul.init();
    });
    document.addEventListener('pjax:error', function (){
        ks.notice("网络连接异常！", {color: "red"});
    });
};
if (window.console && window.console.log) {
    console.log("%c Paul %c https://paul.ren ","color: #fff; margin: 1em 0; padding: 5px 0; background: #1abc9c;","margin: 1em 0; padding: 5px 0; background: #efefef;");
}
paul.init();