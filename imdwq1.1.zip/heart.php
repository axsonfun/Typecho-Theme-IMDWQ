<section class="do-you-like-me">
<div class="heart" onclick="ks.notice('不要按我人家害羞', {color: 'red'});"></div>
</section>