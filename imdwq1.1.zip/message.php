<?php
/**
 * 留言模板
 *
 * @package custom
 */
 ?>
<?php $this->need('head.php'); ?>
<?php $this->need('sidebar.php'); ?>
<main class="is-article">
<br>
<section class="page">
<section class="me" style="text-align: center;">
        <div class="my-avatar" style="display: contents;margin: 0 auto;">
            <a><img style="max-height: 144px;border-radius: 0;" src="https://ae01.alicdn.com/kf/HTB1ShBrb.GF3KVjSZFm762qPXXas.png"></a>
        </div>
        <div class="my-info">
            <h1 style="margin-bottom: 0;"><?php $this->title() ?></h1>
        </div>
    </section>
</section>
<?php $this->need('heart.php'); ?>
<?php $this->need('footer.php'); ?>