<?php $this->need('head.php'); ?>
<?php $this->need('sidebar.php'); ?>
<main>
<br>
<section class="page">
<p style="font-size: 256px;text-align: center;">404</p>
<div class="news-head" style="text-align: center;">
<h3 class="title"><a href="<?php $this->options->siteUrl(); ?>" style="padding: 0;"><i class="fa fa-home"></i>返回首页</a></h3>
</div>
</section>	
<?php $this->need('footer.php'); ?>