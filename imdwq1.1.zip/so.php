<?php
/**
 * 搜索模板
 *
 * @package custom
 */
 ?>
<?php $this->need('head.php'); ?>
<?php $this->need('sidebar.php'); ?>
<main class="is-article">
<br>
<section class="page">
<section class="me" style="text-align: center;">
        <div class="my-avatar" style="display: contents;margin: 0 auto;">
            <a><img style="max-height: 144px;border-radius: 0;" src="https://ae01.alicdn.com/kf/HTB1v4ldbYus3KVjSZKb760qkFXaT.png"></a>
        </div>
        <div class="my-info">
            <h1 style="margin-bottom: 0;"><?php $this->title() ?></h1>
        </div>
    </section>
<div class="news-head" style="text-align: center;">
<h3 class="title" style="display: block;"><a onclick ="so()"><i class="fa fa-search"></i></a><form method="post" action="" name="myform" style="margin-top: -22.5px;">
    <div><input type="text" name="name" class="text" size="32" style="width: 100%;margin-bottom: -19px;border: 0;margin-top: -20px;" autofocus="autofocus" placeholder="输入关键词搜索"/></div>
</form></h3>
</div>
<a href="search/1" id="overso" style="display:none"></a>
</section>
<script type="text/javascript">
function so(){
var name=document.myform.name.value;
var overhref = "search/"+name;
document.getElementById("overso").setAttribute("href",overhref); 
document.getElementById("overso").click();
};
</script>
<?php $this->need('footer.php'); ?>