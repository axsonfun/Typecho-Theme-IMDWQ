<header>
<toggle></toggle>
    <nav class="project-list">
        <a href="<?php $this->options->siteUrl(); ?>"><i class="fa fa-home"></i><span>首页</span></a>
        <?php $this->options->celan(); ?>
        </nav>
</header>