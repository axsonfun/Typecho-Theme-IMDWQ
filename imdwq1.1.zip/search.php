<!DOCTYPE html>
<html class="font-auto">
<head>
    <meta charset="UTF-8">
    <title><?php $this->archiveTitle(array('search'    =>  _t('搜索 “%s”')), '', ''); ?> | <?php $this->options->biaoti(); ?></title>
	<link rel="shortcut icon" href="<?php $this->options->icon(); ?>">
    <link href="<?php $this->options->themeUrl('css.css'); ?>" rel="stylesheet" type="text/css"/>
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1"/>
    <meta name="keywords" content="<?php $this->options->guanjianci(); ?>"/>
    <meta name="description" content="<?php $this->options->miaoshu(); ?>"/>
    <link href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
</head>
<body>
<?php $this->need('sidebar.php'); ?>
<main class="is-article">
<br>
    <section class="me" style="text-align: center;">
        <div class="my-avatar" style="display: contents;margin: 0 auto;">
            <a><img style="max-height: 144px;border-radius: 0;" src="https://ae01.alicdn.com/kf/HTB1v4ldbYus3KVjSZKb760qkFXaT.png"></a>
        </div>
        <div class="my-info">
            <h1 style="margin-bottom: 0;"><?php $this->archiveTitle(array('search'    =>  _t('搜索 “%s” 的文章')), '', ''); ?></h1>
        </div>
    </section>
        <section class="page">
                <section class="project-list">
            <div class="row multi">        
<?php if ($this->have()): ?>
<?php while($this->next()): ?>
<div class="col-12 col-s-3 col-m-6">
                    <a href="<?php $this->permalink() ?>">
                        <img src="<?php $this->fields->toutu(); ?>">
                    </a>
                </div>   
<?php endwhile; ?>		
<?php else: ?>
            <p style="font-size:3em;margin: 0 auto;">没有找到文章</p></div>
        </section> <br><br><br><br> 
			<div class="news-head" style="text-align: center;">
<h3 class="title"><a href="<?php $this->options->siteUrl(); ?>" style="padding: 0;"><i class="fa fa-home"></i>返回首页</a></h3>
</div>
<?php endif; ?>	  
		<br>
<div class="news-head">
                <h3 class="more" style="float: left;"><?php $this->pageLink('<i class="fa fa-chevron-left"></i>'); ?></h3>
			<h3 class="more" style="float: right;"><?php $this->pageLink('<i class="fa fa-chevron-right"></i>','next'); ?></h3>
			</div>
		</section>
<?php $this->need('footer.php'); ?>